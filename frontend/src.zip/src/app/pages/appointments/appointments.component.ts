import { Component, OnInit, ViewChild, TemplateRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { HeaderComponent } from '../../components/header/header.component';
import { ReusableStepperComponent, StepConfig } from '../../components/stepper/stepper.component';
import { ServiceItem } from '../../interfaces/service';
import { PackageItem } from '../../interfaces/package';
import { Professional } from '../../interfaces/professional';
import { SalonDetail } from '../../interfaces/salon.interface';
import { ID } from '../../interfaces/types';
import { SalonService } from '../../services/salon.service';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    HeaderComponent,
    ReusableStepperComponent
  ],
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit, AfterViewInit {
  @ViewChild('serviciosTemplate', { static: true }) serviciosTemplate!: TemplateRef<any>;
  @ViewChild('fechaTemplate', { static: true }) fechaTemplate!: TemplateRef<any>;
  @ViewChild('confirmacionTemplate', { static: true }) confirmacionTemplate!: TemplateRef<any>;
  
  stepConfig: StepConfig[] = [];

  salon: SalonDetail = {
    _id: 1,
    name: 'Salon NailsByO',
    address: 'Calle 123',
    phone: '1234567890',
    description: 'El mejor salón para uñas de la ciudad',
    workingHours: 'L-V 9:00 am - 5:00pm',
    images: ['/assets/images/nails.jpg'],
    rating: 3,
    servicios: [],
    paquetes: [],
    imagen: '/assets/images/nails.jpg',
    services: [],
    registerDate: new Date(),
    isActive: true
  };

  servicios: ServiceItem[] = [
    { id: 1, nombre: 'Estilista', descripcion: 'Este servicio es un corte de cabello', precio: 250 },
    { id: 2, nombre: 'Uñas acrílicas', descripcion: 'Aplicación de uñas acrílicas', precio: 350 },
    { id: 3, nombre: 'Gel', descripcion: 'Aplicación de gel en uñas', precio: 300 },
    { id: 4, nombre: 'Manicure', descripcion: 'Manicure tradicional', precio: 200 }
  ];

  paquetes: PackageItem[] = [
    { id: 'p1', nombre: 'Combo Belleza (Uñas + Gel)', precio: 550, descripcion: 'Incluye uñas acrílicas y aplicación de gel' },
    { id: 'p2', nombre: 'Spa Manos (Manicure + Tratamiento)', precio: 350, descripcion: 'Incluye manicure tradicional y tratamiento hidratante' }
  ];

  personas: Professional[] = [
    { id: 'a1', nombre: 'Andrea', especialidad: 'Estilista y Uñas', foto: 'assets/andrea.jpg' },
    { id: 'b2', nombre: 'Carlos', especialidad: 'Manicure y Pedicure', foto: 'assets/carlos.jpg' },
    { id: 'c3', nombre: 'Fernanda', especialidad: 'Especialista en Acrílicas', foto: 'assets/fernanda.jpg' }
  ];

  horariosDisponibles = [
    '09:00', '10:00', '11:00', '12:00',
    '13:00', '14:00', '16:00', '17:00', '18:00'
  ];

  // Forms
  serviciosForm!: FormGroup;
  fechaForm!: FormGroup;
  confirmacionForm!: FormGroup;

  // Selections
  servicioSeleccionado: ServiceItem | null = null;
  paqueteSeleccionado: PackageItem | null = null;
  personaSeleccionada: Professional | null = null;
  fechaSeleccionada: Date = new Date();
  horarioSeleccionado: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private salonService: SalonService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.initForms();
    this.loadSalonData();
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.stepConfig = [
        {
          label: 'Servicios',
          content: this.serviciosTemplate,
          formGroup: this.serviciosForm
        },
        {
          label: 'Fecha y Hora',
          content: this.fechaTemplate,
          formGroup: this.fechaForm
        },
        {
          label: 'Confirmación',
          content: this.confirmacionTemplate,
          formGroup: this.confirmacionForm
        }
      ];
    });
  }

  loadSalonData(): void {
    this.route.params.subscribe(params => {
      const salonId: ID = params['id'];
      console.log('Salon ID:', salonId);
    });
  }

  initForms(): void {
    this.serviciosForm = this.formBuilder.group({
      servicio: ['', Validators.required],
      paquete: ['']
    });

    this.fechaForm = this.formBuilder.group({
      fecha: [new Date(), Validators.required],
      horario: ['', Validators.required]
    });

    this.confirmacionForm = this.formBuilder.group({
      confirmado: [false, Validators.requiredTrue]
    });

    // Listener para cambios en paquete
    this.serviciosForm.get('paquete')?.valueChanges.subscribe(paqueteId => {
      if (paqueteId) {
        this.paqueteSeleccionado = this.paquetes.find(p => String(p.id) === String(paqueteId)) || null;
        this.servicioSeleccionado = null;
        this.serviciosForm.patchValue({ servicio: '' });
      } else {
        this.paqueteSeleccionado = null;
      }
    });
  }

  // Event handlers del stepper
  onStepChange(index: number): void {
    console.log(`Cambiado al paso ${index + 1}`);
  }

  onNext(currentStep: number): void {
    console.log(`Avanzando desde el paso ${currentStep + 1}`);
  }

  onPrevious(currentStep: number): void {
    console.log(`Retrocediendo desde el paso ${currentStep + 1}`);
  }

  // Métodos de servicios
  seleccionarServicio(servicio: ServiceItem): void {
    this.servicioSeleccionado = servicio;
    this.paqueteSeleccionado = null;
    this.serviciosForm.patchValue({
      servicio: servicio.id,
      paquete: ''
    });
  }

  seleccionarPaquete(paquete: PackageItem): void {
    this.paqueteSeleccionado = paquete;
    this.servicioSeleccionado = null;
    this.serviciosForm.patchValue({ servicio: 'package_' + paquete.id });
  }

  deseleccionarPaquete(): void {
    this.paqueteSeleccionado = null;
    this.serviciosForm.patchValue({ paquete: '' });
  }

  // Métodos de fecha y hora
  seleccionarFecha(event: Date | null): void {
    if (event) {
      this.fechaSeleccionada = event;
      this.fechaForm.patchValue({ fecha: this.fechaSeleccionada });
    }
  }

  seleccionarHorario(horario: string): void {
    this.horarioSeleccionado = horario;
    this.fechaForm.patchValue({ horario: horario });
  }

  // Métodos de profesionales
  seleccionarPersona(persona: Professional): void {
    this.personaSeleccionada = persona;
  }

  limpiarPersona(): void {
    this.personaSeleccionada = null;
  }

  // Métodos utilitarios
  getFechaMostrar(): string {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    };
    return this.fechaSeleccionada.toLocaleDateString('es-ES', options);
  }

  getTotalPrecio(): number {
    if (this.paqueteSeleccionado) {
      return this.paqueteSeleccionado.precio;
    }
    return this.servicioSeleccionado ? this.servicioSeleccionado.precio : 0;
  }

  // Métodos del stepper
  onCancel(): void {
    this.router.navigate(['/salon', this.salon._id]);
  }

  onComplete(): void {
    if (this.confirmacionForm.valid) {
      const appointmentData = {
        salon: this.salon,
        servicio: this.servicioSeleccionado,
        paquete: this.paqueteSeleccionado,
        fecha: this.fechaSeleccionada,
        horario: this.horarioSeleccionado,
        persona: this.personaSeleccionada,
        precioTotal: this.getTotalPrecio()
      };

      console.log('Cita confirmada:', appointmentData);
      alert('¡Tu cita ha sido confirmada con éxito!');
      this.router.navigate(['/home']);
    }
  }
}
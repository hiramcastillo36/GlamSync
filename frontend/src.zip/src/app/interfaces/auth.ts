export interface LoginCredentials {
    email: string;
    username: string;
    password: string;
  }
export interface User {
    msg: string;
    token: string;
    user: any;
  }
